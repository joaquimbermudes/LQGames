import unittest
from LQGames.LQGames import LQGame_Infnity, LQGame_Finity

class TestLQGame(unittest.TestCase):
    def test_simulation(self):
        # Coloque aqui os testes para validar o funcionamento das classes e funções
        pass

if __name__ == "__main__":
    unittest.main()
